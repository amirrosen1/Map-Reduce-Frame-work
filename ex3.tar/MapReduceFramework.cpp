#include <atomic>
#include <csignal>
#include <algorithm>
#include "MapReduceFramework.h"
#include "Barrier.h"
#include <iterator>
#include <iostream>
#include <thread>

// Constants for bit shifting
constexpr uint64_t StageShift = 62;
constexpr uint64_t ProcessedShift = 31;
struct JobContext;
void* mapReduceThreadEntryPoint(void* arg);
void setJobState(JobContext* context, uint32_t processed, uint32_t total, uint32_t stage);

struct ThreadContext {
    int threadID;
    JobContext* jobContext;
};

struct JobContext {
    std::atomic<uint64_t> jobState;  // Stores stage, processedCount, and totalItems
    pthread_mutex_t stateMutex;  // Mutex for job state
    pthread_mutex_t outputMutex; // Mutex for output vector
    pthread_mutex_t joinMutex;   // Mutex for thread joining
    pthread_mutex_t emit2mutex;
    pthread_mutex_t mapMutex;
    std::atomic<bool> threadsJoined; // Atomic boolean for thread join check
    std::atomic<bool> test;
    std::vector<pthread_t> threads;
    const MapReduceClient& client;
    const InputVec &inputVec;
    OutputVec &outputVec;
    std::vector<IntermediateVec> shuffleVectors;
    Barrier barrier;
    std::vector<IntermediateVec> intermediateVectors;
    std::vector<ThreadContext> contexts;
    std::atomic<int> emit2Counter;

    JobContext(const MapReduceClient& c, const InputVec& input, OutputVec& output, int threadLevel)
            : jobState(0), threadsJoined(false), test(false),
              client(c), inputVec(input), outputVec(output), barrier(threadLevel),
              contexts(), emit2Counter(0) {
        pthread_mutex_init(&stateMutex, nullptr);
        pthread_mutex_init(&outputMutex, nullptr);
        pthread_mutex_init(&joinMutex, nullptr);
        pthread_mutex_init(&emit2mutex, nullptr);
        pthread_mutex_init(&mapMutex, nullptr);
        intermediateVectors.resize(threadLevel);
        threads.resize(threadLevel);
        for (int i = 0; i < threadLevel; ++i) {
            contexts.push_back({i, this});
        }
        setJobState(this, 0, inputVec.size(), UNDEFINED_STAGE);

        for (int i = 0; i < threadLevel; ++i) {
            if (pthread_create(&this->threads[i], nullptr, mapReduceThreadEntryPoint, &contexts[i]) != 0) {
                std::cout << "system error: pthread_create failed" << std::endl;
                exit(1);
            }
        }
    }

    void lockMutex(pthread_mutex_t& mutex) {
        if (pthread_mutex_lock(&mutex) != 0) {
            fprintf(stdout, "system error: pthread_mutex_lock failed\n");
            exit(1);
        }
    }

    void unlockMutex(pthread_mutex_t& mutex) {
        if (pthread_mutex_unlock(&mutex) != 0) {
            fprintf(stdout, "system error: pthread_mutex_unlock failed\n");
            exit(1);
        }
    }

    ~JobContext() {
        if (pthread_mutex_destroy(&stateMutex) != 0) {
            fprintf(stdout, "system error: pthread_mutex_destroy failed\n");
            exit(1);
        }
        if (pthread_mutex_destroy(&outputMutex) != 0) {
            fprintf(stdout, "system error: pthread_mutex_destroy failed\n");
            exit(1);
        }
        if (pthread_mutex_destroy(&joinMutex) != 0) {
            fprintf(stdout, "system error: pthread_mutex_destroy failed\n");
            exit(1);
        }
    }
};

// Helper functions to set and get job state
void setJobState(JobContext* context, uint32_t processed, uint32_t total, uint32_t stage) {
    uint64_t state = (static_cast<uint64_t>(stage) << StageShift) |
                     (static_cast<uint64_t>(processed) << ProcessedShift) |
                     static_cast<uint64_t>(total);
    context->jobState.store(state, std::memory_order_relaxed);
}

void getJobState(JobContext* context, uint32_t &processed, uint32_t &total, uint32_t &stage) {
    context->lockMutex(context->stateMutex);
    uint64_t state = context->jobState.load();
    stage = (state >> StageShift) & 0x03;
    processed = (state >> ProcessedShift) & 0x7FFFFFFF;
    total = state & 0x7FFFFFFF;
    context->unlockMutex(context->stateMutex);
}

void getJobState(JobHandle job, JobState* state) {
    auto* jobContext = static_cast<JobContext*>(job);
    uint64_t curState = jobContext->jobState.load();
    uint32_t stage = (curState >> StageShift) & 0x03;
    uint32_t processed = (curState >> ProcessedShift) & 0x7FFFFFFF;
    uint32_t total = curState & 0x7FFFFFFF;
    state->stage = static_cast<stage_t>(stage);
    state->percentage = total == 0 ? 100 : ((float)processed / (float)total) * 100;
}

void waitForJob(JobHandle job) {
    auto* jobContext = static_cast<JobContext*>(job);
    jobContext->lockMutex(jobContext->joinMutex);

    // First check using the atomic boolean
    if (!jobContext->threadsJoined.load()) {
        jobContext->threadsJoined.store(true);
        for (pthread_t& thread : jobContext->threads) {
            if (pthread_join(thread, nullptr) != 0) {
                fprintf(stdout, "system error: pthread_join failed\n");
                exit(1);
            }
        }
    }
    jobContext->unlockMutex(jobContext->joinMutex);
}

void closeJobHandle(JobHandle job) {
    auto* jobContext = static_cast<JobContext*>(job);
    waitForJob(job);
    delete jobContext;
}

void emit2(K2* key, V2* value, void* context) {
    auto* threadContext = static_cast<ThreadContext*>(context);
    auto* jobContext = threadContext->jobContext;
    jobContext->lockMutex(jobContext->emit2mutex);
    int threadID = threadContext->threadID;
    jobContext->intermediateVectors[threadID].emplace_back(key, value);
    jobContext->emit2Counter++;
    jobContext->unlockMutex(jobContext->emit2mutex);
}

void emit3(K3* key, V3* value, void* context) {
    auto* threadContext = static_cast<ThreadContext*>(context);
    auto* jobContext = threadContext->jobContext;
    jobContext->lockMutex(jobContext->outputMutex);
    jobContext->outputVec.emplace_back(key, value);
    jobContext->unlockMutex(jobContext->outputMutex);
}

void* mapReduceThreadEntryPoint(void* arg) {
    auto args = static_cast<ThreadContext*>(arg);
    auto jobContext = args->jobContext;
    int threadID = args->threadID;

    jobContext->lockMutex(jobContext->mapMutex);
    if (!jobContext->test.load()) {
        jobContext->test.store(true);
        setJobState(jobContext, 0, jobContext->inputVec.size(), MAP_STAGE);
    }
    jobContext->unlockMutex(jobContext->mapMutex);

    jobContext->barrier.barrier();

    while (true) {
        jobContext->lockMutex(jobContext->stateMutex);
        uint64_t state = jobContext->jobState.load();
        uint32_t processed = (state >> ProcessedShift) & 0x7FFFFFFF;
        uint32_t total = state & 0x7FFFFFFF;
        if (processed >= total) {
            jobContext->unlockMutex(jobContext->stateMutex);
            break;
        }
        uint32_t idx = processed;

        uint64_t newState = state + (1ull << ProcessedShift);
        jobContext->jobState.store(newState, std::memory_order_relaxed);
        jobContext->unlockMutex(jobContext->stateMutex);

        jobContext->client.map(jobContext->inputVec[idx].first, jobContext->inputVec[idx].second, arg);
    }

    jobContext->barrier.barrier();

    if (threadID == 0) {
        setJobState(jobContext, 0, jobContext->emit2Counter, SHUFFLE_STAGE);

        std::vector<IntermediatePair> shuffledData;
        for (auto& vec : jobContext->intermediateVectors) {
            shuffledData.insert(shuffledData.end(), vec.begin(), vec.end());
        }
        std::sort(shuffledData.begin(), shuffledData.end(),
                  [](const IntermediatePair& a, const IntermediatePair& b) { return *(a.first) < *(b.first); });

        auto it = shuffledData.begin();
        while (it != shuffledData.end()) {
            auto key = it->first;
            auto end = std::find_if(it + 1, shuffledData.end(), [&key](const IntermediatePair& p) { return *(p.first) < *key || *key < *(p.first); });
            IntermediateVec vec(it, end);
            jobContext->shuffleVectors.push_back(vec);

            jobContext->lockMutex(jobContext->stateMutex);
            uint64_t state = jobContext->jobState.load();
            uint64_t newState = state + ((end - it) << ProcessedShift);
            jobContext->jobState.store(newState, std::memory_order_relaxed);
            jobContext->unlockMutex(jobContext->stateMutex);

            it = end;
        }
    }

    jobContext->barrier.barrier();

    if (threadID == 0) {
        setJobState(jobContext, 0, jobContext->shuffleVectors.size(), REDUCE_STAGE);
    }
    jobContext->barrier.barrier();

    while (true) {
        jobContext->lockMutex(jobContext->stateMutex);
        uint64_t state = jobContext->jobState.load();
        uint32_t processed = (state >> ProcessedShift) & 0x7FFFFFFF;
        uint32_t total = state & 0x7FFFFFFF;
        if (processed >= total) {
            jobContext->unlockMutex(jobContext->stateMutex);
            break;
        }
        uint32_t idx = processed;

        uint64_t newState = state + (1ull << ProcessedShift);
        jobContext->jobState.store(newState, std::memory_order_relaxed);
        jobContext->unlockMutex(jobContext->stateMutex);

        jobContext->client.reduce(&jobContext->shuffleVectors[idx], args);
    }

    return nullptr;
}

JobHandle startMapReduceJob(const MapReduceClient& client, const InputVec& inputVec, OutputVec& outputVec, int multiThreadLevel) {
    auto* jobContext = new JobContext(client, inputVec, outputVec, multiThreadLevel);
    return jobContext;
}
